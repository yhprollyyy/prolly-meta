package com.prollymeta.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ProllyConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("prollymeta.json");

    public boolean storageEsp = true;
    public boolean spawnerFinder = true;
    public boolean storageFill = false;
    public boolean spawnerFill = false;
    public int storageColor = 0xFFFF79B8;
    public int spawnerColor = 0xFFB98CFF;
    public int storageAlpha = 95;
    public int spawnerAlpha = 110;
    public int lineWidth = 2;
    public int range = 48;

    public static ProllyConfig load() {
        try {
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE)) {
                    ProllyConfig c = GSON.fromJson(reader, ProllyConfig.class);
                    if (c != null) return c;
                }
            }
        } catch (Exception ignored) { }
        ProllyConfig c = new ProllyConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(this, writer);
            }
        } catch (Exception ignored) { }
    }
}
