package com.prollymeta.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class ProllyScreen extends Screen {
    private static final int PINK = 0xFFFF79B8;
    private static final int TEXT = 0xFFF5F2F5;
    private static final int MUTED = 0xFFAAA4AF;
    private static final int PANEL = 0xF20E0D12;
    private static final int CARD = 0xE817151D;
    private static final int CARD_HOVER = 0xF0221D29;
    private static final int BORDER = 0xFF3A3440;
    private static final Identifier LOGO = Identifier.of("prollymeta", "logo.png");

    private int tab = 0;
    private int storagePalette = 0;
    private int spawnerPalette = 1;
    private static final int[] PALETTE = {
            0xFFFF79B8, 0xFFFF4F91, 0xFFFF9FC9, 0xFFB98CFF,
            0xFF7FD8FF, 0xFF8CFFB0, 0xFFFFD36E, 0xFFFF6B6B,
            0xFFFFFFFF, 0xFF7E8CFF
    };

    public ProllyScreen() {
        super(Text.literal("Prolly Meta"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        renderBackground(context, mouseX, mouseY, deltaTicks);
        int w = this.width;
        int h = this.height;
        int panelW = Math.min(1050, w - 60);
        int panelH = Math.min(650, h - 40);
        int x = (w - panelW) / 2;
        int y = (h - panelH) / 2;
        int side = 205;

        roundedPanel(context, x, y, panelW, panelH, PANEL, PINK);
        context.fill(x + side, y + 1, x + side + 1, y + panelH - 1, 0xFF2C2730);

        // sidebar
        context.drawTexture(LOGO, x + 62, y + 22, 0, 0, 80, 80);
        drawCentered(context, "PROLLY", x + side / 2, y + 104, PINK);
        drawCentered(context, "META", x + side / 2, y + 120, MUTED);

        String[] tabs = {"Visuals", "Settings"};
        for (int i = 0; i < tabs.length; i++) {
            int by = y + 165 + i * 45;
            boolean selected = tab == i;
            if (selected) roundedRect(context, x + 14, by, side - 28, 34, 0xFFE858A0, 0xFFE858A0);
            context.drawTextWithShadow(this.textRenderer, tabs[i], x + 38, by + 10, selected ? 0xFFFFFFFF : TEXT);
        }

        context.fill(x + 30, y + panelH - 78, x + side - 30, y + panelH - 77, 0xFF3A3440);
        drawCentered(context, "PLAY SMARTER", x + side / 2, y + panelH - 60, PINK);
        drawCentered(context, "NOT HARDER", x + side / 2, y + panelH - 44, MUTED);

        // header
        context.drawTextWithShadow(this.textRenderer, tab == 0 ? "Visuals" : "Settings", x + side + 28, y + 26, TEXT);
        context.drawTextWithShadow(this.textRenderer, tab == 0 ? "Storage and world ESP" : "Fine tune your overlay", x + side + 28, y + 46, MUTED);
        context.drawTextWithShadow(this.textRenderer, "—", x + panelW - 72, y + 27, MUTED);
        context.drawTextWithShadow(this.textRenderer, "×", x + panelW - 45, y + 24, PINK);

        if (tab == 0) drawVisuals(context, x + side + 28, y + 78, panelW - side - 56, mouseX, mouseY);
        else drawSettings(context, x + side + 28, y + 78, panelW - side - 56, mouseX, mouseY);
    }

    private void drawVisuals(DrawContext c, int x, int y, int width, int mx, int my) {
        drawModule(c, x, y, width, "StorageESP", "Highlights chests, hoppers and shulkers.", ProllyMetaClient.CONFIG.storageEsp, mx, my, () -> {
            ProllyMetaClient.CONFIG.storageEsp = !ProllyMetaClient.CONFIG.storageEsp; ProllyMetaClient.CONFIG.save();
        });
        drawModule(c, x, y + 92, width, "SpawnerFinder", "Highlights mob spawners through the world.", ProllyMetaClient.CONFIG.spawnerFinder, mx, my, () -> {
            ProllyMetaClient.CONFIG.spawnerFinder = !ProllyMetaClient.CONFIG.spawnerFinder; ProllyMetaClient.CONFIG.save();
        });

        int cy = y + 190;
        c.drawTextWithShadow(this.textRenderer, "OUTLINE COLORS", x, cy, TEXT);
        c.drawTextWithShadow(this.textRenderer, "Click a swatch to cycle palettes", x, cy + 18, MUTED);

        swatch(c, x, cy + 45, 190, 45, "Storage", PALETTE[storagePalette], mx, my);
        swatch(c, x + 205, cy + 45, 190, 45, "Spawner", PALETTE[spawnerPalette], mx, my);

        int by = cy + 108;
        smallButton(c, x, by, 190, 42, "Storage fill: " + onOff(ProllyMetaClient.CONFIG.storageFill), mx, my);
        smallButton(c, x + 205, by, 190, 42, "Spawner fill: " + onOff(ProllyMetaClient.CONFIG.spawnerFill), mx, my);
        smallButton(c, x, by + 52, 190, 42, "Opacity: " + ProllyMetaClient.CONFIG.storageAlpha + "%", mx, my);
        smallButton(c, x + 205, by + 52, 190, 42, "Line width: " + ProllyMetaClient.CONFIG.lineWidth, mx, my);
        smallButton(c, x, by + 104, 395, 42, "Scan range: " + ProllyMetaClient.CONFIG.range + " blocks", mx, my);
    }

    private void drawSettings(DrawContext c, int x, int y, int width, int mx, int my) {
        c.drawTextWithShadow(this.textRenderer, "PROLLY META", x, y, PINK);
        c.drawTextWithShadow(this.textRenderer, "Client-side visual utilities for Fabric 1.21.11", x, y + 24, MUTED);
        smallButton(c, x, y + 65, 395, 42, "Reset visual defaults", mx, my);
        c.drawTextWithShadow(this.textRenderer, "Right Shift", x, y + 135, TEXT);
        c.drawTextWithShadow(this.textRenderer, "Open / close the GUI", x, y + 154, MUTED);
        c.drawTextWithShadow(this.textRenderer, "Config", x, y + 195, TEXT);
        c.drawTextWithShadow(this.textRenderer, ".minecraft/config/prollymeta.json", x, y + 214, MUTED);
    }

    private void drawModule(DrawContext c, int x, int y, int width, String name, String desc, boolean enabled, int mx, int my, Runnable click) {
        boolean hover = inside(mx, my, x, y, width, 78);
        roundedRect(c, x, y, width, 78, hover ? CARD_HOVER : CARD, BORDER);
        c.drawTextWithShadow(this.textRenderer, name, x + 20, y + 19, TEXT);
        c.drawTextWithShadow(this.textRenderer, desc, x + 20, y + 42, MUTED);
        toggle(c, x + width - 70, y + 25, enabled);
    }

    private void swatch(DrawContext c, int x, int y, int w, int h, String label, int color, int mx, int my) {
        boolean hover = inside(mx, my, x, y, w, h);
        roundedRect(c, x, y, w, h, hover ? CARD_HOVER : CARD, BORDER);
        c.fill(x + 12, y + 11, x + 34, y + h - 11, color);
        c.drawTextWithShadow(this.textRenderer, label, x + 45, y + 9, TEXT);
        c.drawTextWithShadow(this.textRenderer, String.format("#%06X", color & 0xFFFFFF), x + 45, y + 25, MUTED);
    }

    private void smallButton(DrawContext c, int x, int y, int w, int h, String text, int mx, int my) {
        roundedRect(c, x, y, w, h, inside(mx, my, x, y, w, h) ? CARD_HOVER : CARD, BORDER);
        c.drawTextWithShadow(this.textRenderer, text, x + 14, y + 13, TEXT);
    }

    private void toggle(DrawContext c, int x, int y, boolean enabled) {
        roundedRect(c, x, y, 48, 28, enabled ? 0xFFE858A0 : 0xFF2A2730, enabled ? 0xFFE858A0 : 0xFF514B56);
        c.fill(enabled ? x + 25 : x + 5, y + 5, enabled ? x + 43 : x + 23, y + 23, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int mx = (int) click.x();
        int my = (int) click.y();
        if (click.button() != GLFW.GLFW_MOUSE_BUTTON_1) return super.mouseClicked(click, doubled);

        int panelW = Math.min(1050, width - 60);
        int panelH = Math.min(650, height - 40);
        int x = (width - panelW) / 2;
        int y = (height - panelH) / 2;
        int side = 205;

        if (inside(mx, my, x + 14, y + 165, side - 28, 34)) { tab = 0; return true; }
        if (inside(mx, my, x + 14, y + 210, side - 28, 34)) { tab = 1; return true; }
        if (inside(mx, my, x + panelW - 58, y + 10, 45, 35)) { close(); return true; }

        int cx = x + side + 28;
        int cy = y + 78;
        int width = panelW - side - 56;

        if (tab == 0) {
            if (inside(mx, my, cx, cy, width, 78)) { ProllyMetaClient.CONFIG.storageEsp = !ProllyMetaClient.CONFIG.storageEsp; ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx, cy + 92, width, 78)) { ProllyMetaClient.CONFIG.spawnerFinder = !ProllyMetaClient.CONFIG.spawnerFinder; ProllyMetaClient.CONFIG.save(); return true; }
            int sy = cy + 190 + 45;
            if (inside(mx, my, cx, sy, 190, 45)) { storagePalette = (storagePalette + 1) % PALETTE.length; ProllyMetaClient.CONFIG.storageColor = PALETTE[storagePalette]; ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx + 205, sy, 190, 45)) { spawnerPalette = (spawnerPalette + 1) % PALETTE.length; ProllyMetaClient.CONFIG.spawnerColor = PALETTE[spawnerPalette]; ProllyMetaClient.CONFIG.save(); return true; }
            int by = cy + 190 + 108;
            if (inside(mx, my, cx, by, 190, 42)) { ProllyMetaClient.CONFIG.storageFill = !ProllyMetaClient.CONFIG.storageFill; ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx + 205, by, 190, 42)) { ProllyMetaClient.CONFIG.spawnerFill = !ProllyMetaClient.CONFIG.spawnerFill; ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx, by + 52, 190, 42)) { ProllyMetaClient.CONFIG.storageAlpha = next(ProllyMetaClient.CONFIG.storageAlpha, 55, 75, 95, 115, 140, 170, 210, 255); ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx + 205, by + 52, 190, 42)) { ProllyMetaClient.CONFIG.lineWidth = next(ProllyMetaClient.CONFIG.lineWidth, 1, 2, 3, 4); ProllyMetaClient.CONFIG.save(); return true; }
            if (inside(mx, my, cx, by + 104, 395, 42)) { ProllyMetaClient.CONFIG.range = next(ProllyMetaClient.CONFIG.range, 16, 24, 32, 48, 64, 80); ProllyMetaClient.CONFIG.save(); return true; }
        } else {
            if (inside(mx, my, cx, cy + 65, 395, 42)) {
                ProllyMetaClient.CONFIG.storageEsp = true; ProllyMetaClient.CONFIG.spawnerFinder = true;
                ProllyMetaClient.CONFIG.storageFill = false; ProllyMetaClient.CONFIG.spawnerFill = false;
                ProllyMetaClient.CONFIG.storageColor = PINK; ProllyMetaClient.CONFIG.spawnerColor = 0xFFB98CFF;
                ProllyMetaClient.CONFIG.storageAlpha = 95; ProllyMetaClient.CONFIG.spawnerAlpha = 110;
                ProllyMetaClient.CONFIG.lineWidth = 2; ProllyMetaClient.CONFIG.range = 48;
                storagePalette = 0; spawnerPalette = 3; ProllyMetaClient.CONFIG.save(); return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private static int next(int current, int... values) {
        for (int i = 0; i < values.length; i++) if (current == values[i]) return values[(i + 1) % values.length];
        return values[0];
    }

    private static String onOff(boolean value) { return value ? "ON" : "OFF"; }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    private static void roundedRect(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x + 4, y, x + w - 4, y + h, fill);
        c.fill(x, y + 4, x + w, y + h - 4, fill);
        c.fill(x + 4, y, x + w - 4, y + 1, border);
        c.fill(x + 4, y + h - 1, x + w - 4, y + h, border);
        c.fill(x, y + 4, x + 1, y + h - 4, border);
        c.fill(x + w - 1, y + 4, x + w, y + h - 4, border);
    }

    private static void drawCentered(DrawContext c, String text, int centerX, int y, int color) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        c.drawTextWithShadow(tr, text, centerX - tr.getWidth(text) / 2, y, color);
    }
}
