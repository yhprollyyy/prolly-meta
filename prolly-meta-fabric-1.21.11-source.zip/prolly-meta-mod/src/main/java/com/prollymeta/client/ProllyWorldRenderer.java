package com.prollymeta.client;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class ProllyWorldRenderer {
    private ProllyWorldRenderer() {}

    public static void render(WorldRenderContext context) {
        MinecraftAccess.render(context);
    }

    private static final class MinecraftAccess {
        private static void render(WorldRenderContext context) {
            if (!ProllyConfigHolder.enabled()) return;
            var client = net.minecraft.client.MinecraftClient.getInstance();
            World world = client.world;
            if (world == null) return;
            Vec3d camera = context.gameRenderer().getCamera().getCameraPos();
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            int r = ProllyConfigHolder.range();
            BlockPos origin = BlockPos.ofFloored(camera);
            BlockPos min = origin.add(-r, -r, -r);
            BlockPos max = origin.add(r, r, r);
            VertexConsumer lines = consumers.getBuffer(RenderLayers.LINES);

            for (BlockPos pos : BlockPos.iterate(min, max)) {
                BlockState state = world.getBlockState(pos);
                BlockEntity be = world.getBlockEntity(pos);
                boolean storage = ProllyConfigHolder.storage() && isStorage(state, be);
                boolean spawner = ProllyConfigHolder.spawner() && isSpawner(be, state);
                if (!storage && !spawner) continue;

                int color = spawner ? ProllyConfigHolder.spawnerColor() : ProllyConfigHolder.storageColor();
                float rr = ((color >> 16) & 255) / 255f;
                float gg = ((color >> 8) & 255) / 255f;
                float bb = (color & 255) / 255f;
                float alpha = (spawner ? ProllyConfigHolder.spawnerAlpha() : ProllyConfigHolder.storageAlpha()) / 255f;

                matrices.push();
                matrices.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
                Box box = new Box(0.002, 0.002, 0.002, 0.998, 0.998, 0.998);
                WorldRenderer.drawBox(matrices, lines, box, rr, gg, bb, alpha);
                matrices.pop();
            }
        }

        private static boolean isStorage(BlockState state, BlockEntity be) {
            if (be != null) {
                BlockEntityType<?> type = be.getType();
                if (type == BlockEntityType.CHEST || type == BlockEntityType.TRAPPED_CHEST || type == BlockEntityType.HOPPER || type == BlockEntityType.SHULKER_BOX) return true;
            }
            return state.isIn(BlockTags.SHULKER_BOXES) || state.isOf(Blocks.HOPPER) || state.isOf(Blocks.CHEST) || state.isOf(Blocks.TRAPPED_CHEST);
        }

        private static boolean isSpawner(BlockEntity be, BlockState state) {
            return be != null && be.getType() == BlockEntityType.MOB_SPAWNER || state.isOf(Blocks.SPAWNER);
        }
    }

    private static final class ProllyConfigHolder {
        static boolean enabled() { return ProllyMetaClient.CONFIG.storageEsp || ProllyMetaClient.CONFIG.spawnerFinder; }
        static boolean storage() { return ProllyMetaClient.CONFIG.storageEsp; }
        static boolean spawner() { return ProllyMetaClient.CONFIG.spawnerFinder; }
        static int range() { return ProllyMetaClient.CONFIG.range; }
        static double lineWidth() { return ProllyMetaClient.CONFIG.lineWidth; }
        static int storageColor() { return ProllyMetaClient.CONFIG.storageColor; }
        static int spawnerColor() { return ProllyMetaClient.CONFIG.spawnerColor; }
        static int storageAlpha() { return ProllyMetaClient.CONFIG.storageAlpha; }
        static int spawnerAlpha() { return ProllyMetaClient.CONFIG.spawnerAlpha; }
    }
}
