# Prolly Meta — Fabric 1.21.11

Client-side Fabric mod project for Minecraft Java 1.21.11.

## Included

- Pink/charcoal Prolly Meta click GUI, opened with **Right Shift**.
- StorageESP for chests, trapped chests, hoppers and every shulker-box color.
- SpawnerFinder for mob spawners.
- Persistent JSON config at `.minecraft/config/prollymeta.json`.
- Palette cycling for storage/spawner outline colors.
- Toggleable storage/spawner fill settings, opacity, line width and scan range controls.
- No server-side code; the requested visuals are client-side.

## Build

Use Java 21. From the project folder run:

```text
./gradlew build
```

The output jar will be under `build/libs/`.

## Install

Put the built `prolly-meta-1.0.0.jar` in `%APPDATA%\\.minecraft\\mods` alongside Fabric API for Minecraft 1.21.11.

## Notes

Minecraft 1.21.11 is the last obfuscated Minecraft release; Fabric's 1.21.11 guidance recommends Loom 1.14 and Fabric Loader 0.18.1. This project uses Yarn 1.21.11+build.6 and Fabric API 0.141.6+1.21.11.
